﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Saransk_Avia_Lanes
{

    public partial class AddFlightWindow : Window
    {
        public AddFlightWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

            if (IdTextBox.Text == "" || DirectionTextBox.Text == "" || PlaneTextBox.Text == ""
                || AirlineTextBox.Text == "" || DepartureTimeTextBox.Text == "" ||
                ArrivaltimeTextBox.Text == "")
            {
                MessageBox.Show("Заполните все поля данными!");
            }
            else if (AirlinesContext.db.Flights.Any(flight => flight.Id == long.Parse(IdTextBox.Text))) {
                MessageBox.Show("Такой Id уже существует");
            }
            else
            {
                Flight flight = new Flight()
                {

                    Id = long.Parse(IdTextBox.Text),
                    Direction = DirectionTextBox.Text,
                    Plane = PlaneTextBox.Text,
                    Airline = AirlineTextBox.Text,
                    DepartureTime = DirectionTextBox.Text,
                    ArrivalTime = ArrivaltimeTextBox.Text
                };
                MainMenuWindow mainMenuWindow = new MainMenuWindow();
                mainMenuWindow.SetNewFlight(flight);
                mainMenuWindow.Show();
                Close();
            }
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainMenuWindow mainMenuWindow = new MainMenuWindow();
            mainMenuWindow.Show();
            Close();
        }
    }
}
