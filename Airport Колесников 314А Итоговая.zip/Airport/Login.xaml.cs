﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Saransk_Avia_Lanes
{

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            AirlinesContext.db = new SaranskAirlinesContext();
        }

        private void Join_Click(object sender, RoutedEventArgs e)
        {
            // password = admin, login = admin для администратора, pass= user login=user для пользователя
            var user = AirlinesContext.db.Users.FirstOrDefault(user => user.Password == psbPassword.Password || user.Login == txbLogin.Text);

            if (user != null)
            {
                // Проверяем роль пользователя и открываем соответствующее окно
                if (user.Login == "admin") // Проверяем роль администратора
                {
                    MainMenuWindow mainMenuWindow = new MainMenuWindow();
                    mainMenuWindow.Show();
                }
                else if (user.Login == "user") // Проверяем роль пользователя
                {
                    UserWindow userWindow = new UserWindow();
                    userWindow.Show();
                }

                Close(); // Закрываем текущее окно входа
            }
            else
            {
                MessageBox.Show("Данные неверны");
            }
        }

        private void Cancel_Click(object sender, RoutedEventArgs e)
        {
            txbLogin.Clear();
            psbPassword.Clear();
        }

        private void txbLogin_TextChanged(object sender, TextChangedEventArgs e)
        {

        }
    }
}
