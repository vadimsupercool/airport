﻿using System;
using System.Collections.Generic;

namespace Saransk_Avia_Lanes;

public partial class User
{
    public long Id { get; set; }

    public string Login { get; set; } = null!;

    public string Password { get; set; } = null!;

    public string Name { get; set; } = null!;
}
