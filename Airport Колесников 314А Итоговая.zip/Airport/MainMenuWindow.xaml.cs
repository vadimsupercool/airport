﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Media.Media3D;
using System.Windows.Shapes;

namespace Saransk_Avia_Lanes
{
    /// <summary>
    /// Логика взаимодействия для MainMenuWindow.xaml
    /// </summary>
    public partial class MainMenuWindow : Window
    {
        private List<Flight> flights = AirlinesContext.db.Flights.ToList();

        public MainMenuWindow()
        {
            InitializeComponent();
            FlightsGrid.ItemsSource = flights;
        }

        public void SetNewFlight(Flight flight)
        {
            AirlinesContext.db.Flights.Add(flight);
            flights.Add(flight);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            AddFlightWindow addFlightWindow = new AddFlightWindow();
            addFlightWindow.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            Close();
        }
    }
}
