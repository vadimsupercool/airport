﻿using System;
using System.Collections.Generic;

namespace Saransk_Avia_Lanes;

public partial class Flight
{
    public long Id { get; set; }

    public string Direction { get; set; } = null!;

    public string Plane { get; set; } = null!;

    public string Airline { get; set; } = null!;

    public string DepartureTime { get; set; } = null!;

    public string ArrivalTime { get; set; } = null!;
}
